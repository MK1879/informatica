
public class Mensola {

    private static final int MAX_NUM_VOLUMI = 15;
    private final Libro volumi[];

    public Mensola() {
        volumi = new Libro[MAX_NUM_VOLUMI];
    }

    public Mensola(Mensola mensola) {
        int posizione;
        volumi = new Libro[MAX_NUM_VOLUMI];
        for (posizione = 0; posizione < MAX_NUM_VOLUMI; posizione++) {
            if (mensola.getVolume(posizione) != null) {
                volumi[posizione] = new Libro(mensola.getVolume(posizione));
            }
        }
    }

    public int setVolume(Libro libro, int posizione) {
        if ((posizione < 0) || (posizione >= MAX_NUM_VOLUMI)) {
            return -1; // posizione non valida
        }
        if (volumi[posizione] != null) {
            return -2; // posizione occupata
        }// inserimento copia di libro in posizione
        volumi[posizione] = new Libro(libro);
        return posizione; // restituisce la posizione di inserimento
    }

    public Libro getVolume(int posizione) {
        if ((posizione < 0) || (posizione >= MAX_NUM_VOLUMI)) {
            return null; // posizione non valida: nessun libro restituito
        }// restituisce una copia del libro in posizione
        if (volumi[posizione] != null) {
            return new Libro(volumi[posizione]);
        } else {
            return null;
        }
    }

    public int rimuoviVolume(int posizione) {
        if ((posizione < 0) || (posizione >= MAX_NUM_VOLUMI)) {
            return -1; // posizione non valida
        }
        if (volumi[posizione] == null) {
            return -2; // posizione vuota
        }
        volumi[posizione] = null; // rimozione libro in posizione
        return posizione; // restituisce la posizione liberata
    }

    public int getNumMaxVolumi() {
        return MAX_NUM_VOLUMI;
    }

    public int getNumVolumi() {
        int posizione, n = 0;
        for (posizione = 0; posizione < MAX_NUM_VOLUMI; posizione++) {
            if (volumi[posizione] != null) {
                n++;
            }
        }
        return n;
    }
}
