public class Libro {
    private String titolo;
    private String autore;
    private int numPagine;
    private static double costoPagina = 0.5;
    final double COSTO_FISSO = 5.5;

    public Libro(String titolo, String autore, int numPagine)
    {
        this.titolo=titolo;
        this.autore=autore;
        this.numPagine=numPagine;
    }

    public Libro(Libro Libro)
    {
        this.titolo=Libro.getTitolo();
        this.autore=Libro.getAutore();
        this.numPagine=Libro.getNumPagine();
    }
    public void setAutore(String autore) {
        this.autore = autore;
    }
    public void setNumPagine(int numPagine) {
        this.numPagine = numPagine;
    }
    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }
    public String getAutore() {
        return autore;
    }public int getNumPagine() {
        return numPagine;
    }public String getTitolo() {
        return titolo;
    }
    public double prezzo()
    {
        return COSTO_FISSO+numPagine*costoPagina;
    }
    public static void setCostoPagina(double costoPagina) {
        Libro.costoPagina = costoPagina;
    }

    
}