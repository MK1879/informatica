public class TagElettronico
{
    private int codice;
    private double distanza;
    private Coordinate coordinate; 

    public TagElettronico(int cod, double dis, Coordinate coordinate)
    {
        this.codice=cod;
        this.distanza=dis;
        this.coordinate=coordinate;
    }
    public int getCodice() 
    {
        return this.codice;
    }
    public double getDistanza() {
        return this.distanza;
    }
    public void setCodice(int cod) 
    {
        this.codice = cod;
    }
    public void setDistanza(double dis) 
    {
        this.distanza = dis;
    }
    public String toString() 
    {
        return "TagElettronico {" +
                "codiceUnitario='" + this.codice + '\'' +
                ", distanza=" + this.distanza +
                ", posizione=(" +coordinate.toString()+
                "}";
    }
}