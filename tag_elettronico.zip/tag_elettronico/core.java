import java.util.Scanner;
public class core {
    private int codice;
    private float distanza;
    private Coordinate coordinate;
    

    public void rilevazione(int codice, float distanza, Coordinate coordinate)
    {
        this.codice=codice;
        this.distanza=distanza;
        this.coordinate=coordinate;
    }
    
}